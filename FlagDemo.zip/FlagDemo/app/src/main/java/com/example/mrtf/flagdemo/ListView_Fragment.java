package com.example.mrtf.flagdemo;


import android.os.Bundle;
import android.app.Fragment;
import android.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class ListView_Fragment extends ListFragment {

    private ArrayList<Flag> flaglist=new ArrayList<>();
    private static final String[] flags = {"china", "finland", "france", "algeria", "aruba", "chile", "denmark", "ecuador", "austria", "dominica", "afghanistan", "albania", "angola", "japan", "germany",
    };
    private ListView listView;
    private FlagAdapter adapter;
    private View view;

    public ListView_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
         view=inflater.inflate(R.layout.fragment_list_view, container, false);
         listView=view.findViewById(android.R.id.list);
         InitWithData();
         listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
             @Override
             public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                 MainActivity activity = (MainActivity) getActivity();
                 activity.GetIndex(position);
                 return true;
             }
         });
         return view;
    }

    public void InitWithData()
    {
        for (String flag :flags)
        {
            Flag flag1=new Flag(flag.substring(0, 1).toUpperCase()+flag.substring(1).toLowerCase(),getResources().getIdentifier(flag, "drawable", this.getActivity().getPackageName()));
            flaglist.add(flag1);
        }
        adapter= new FlagAdapter(this.getActivity(),R.layout.flag_item,flaglist);
        listView.setAdapter(adapter);
    }
    public void onListItemClick(ListView l, View v, int position, long id) {

        Flag selfModel = (Flag)adapter.getItem(position);
        MainActivity activity = (MainActivity) getActivity();
        activity.GetModel(selfModel);
    }
    public void deleteData(int index)
    {
        flaglist.remove(index);
        listView.setAdapter(adapter);
    }


}
