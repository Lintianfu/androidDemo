package com.example.mrtf.flagdemo;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.res.Configuration;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Delete_Fragment fragment2;
    private ListView_Fragment fragment1;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setContentView(R.layout.land);
        }
        else {
            setContentView(R.layout.activity_main);
        }
    }
    public void GetModel(Flag model)
    {
        String name=model.getName().toLowerCase();
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)
        {
            Intent intent = new Intent(MainActivity.this, Main2Activity.class);
            intent.putExtra("flagname", name);
            startActivity(intent);
        }
        else
        {
            Intent intent2 = new Intent("MainActivitytofragment");
            intent2.putExtra("flagname",name);
            LocalBroadcastManager.getInstance(MainActivity.this).sendBroadcast(intent2);
        }
    }

    public void GetIndex(int position)
    {

        FragmentManager fragmentManager=getFragmentManager();
        Bundle bundle = new Bundle();
        bundle.putInt("index",position);
        fragment2=new Delete_Fragment();
        fragment2.setArguments(bundle);
        fragment2.show(fragmentManager,"delete_dlg");
    }
   public void onUserSelect(String selecteValue,int index)
    {
        if(selecteValue.equalsIgnoreCase("yes"))
        {
            FragmentManager fragmentManager=getFragmentManager();
            fragment1 = (ListView_Fragment) fragmentManager.findFragmentById(R.id.list_fragment);
            fragment1.deleteData(index);
            fragment2.dismiss();
        }
        else
        {
            fragment2.dismiss();
        }
    }
}
