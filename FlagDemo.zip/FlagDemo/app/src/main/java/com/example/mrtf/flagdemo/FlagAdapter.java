package com.example.mrtf.flagdemo;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class FlagAdapter extends ArrayAdapter<Flag> {
    private int resourceId;
    public FlagAdapter(@NonNull Context context, int resource, @NonNull List<Flag> objects) {
        super(context, resource, objects);
        resourceId=resource;
    }
    public View getView(int position, View convertView, ViewGroup parent) {
        Flag flag=getItem(position);
        ViewHolder viewHolder;
        if (convertView==null)
        {
            viewHolder=new ViewHolder();
            convertView= LayoutInflater.from(getContext()).inflate(resourceId,parent,false);
            viewHolder.flagImage= (ImageView)convertView.findViewById(R.id.flag_view);
            viewHolder.flagText= (TextView) convertView.findViewById(R.id.flag_name);
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder= (ViewHolder) convertView.getTag();
            }
            viewHolder.flagImage.setImageResource(flag.getImageId());
            viewHolder.flagText.setText(flag.getName());
            return convertView;
    }
     public final class ViewHolder
    {
        public ImageView flagImage;
        public TextView flagText;
    }
}
