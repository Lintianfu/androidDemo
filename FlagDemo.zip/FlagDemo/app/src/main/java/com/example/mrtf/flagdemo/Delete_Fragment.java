package com.example.mrtf.flagdemo;


import android.os.Bundle;
import android.app.DialogFragment;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class Delete_Fragment extends DialogFragment {

   View view;
    public Delete_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final int flag=getArguments().getInt("index");
        view=inflater.inflate(R.layout.fragment_delete_, container, false);



        Button btn_yes=view.findViewById(R.id.button_yes);
        Button btn_on=view.findViewById(R.id.button_no);

        btn_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MainActivity mainActivity=(MainActivity) getActivity();
                mainActivity.onUserSelect("yes",flag);
            }
        });
        btn_on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v("button2","no");
                MainActivity mainActivity=(MainActivity) getActivity();
                mainActivity.onUserSelect("no",flag);
            }
        });

        return view;

    }

}
