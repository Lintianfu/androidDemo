package com.example.mrtf.flagdemo;


import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


public class Detail_Fragment extends Fragment {

    private View view;
    private Context context;
    private String result;
    private Bundle bundle;
    private TextView txt;
    private ImageView img;
    private NameChangeReceiver nameChangeReceiver;
    private  IntentFilter filter;
    public Detail_Fragment(){

    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        nameChangeReceiver=new NameChangeReceiver();
        filter=new IntentFilter("MainActivitytofragment");
        bundle = getArguments();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_detail_, container, false);
        txt=view.findViewById(R.id.text_view);
        img=view.findViewById(R.id.img_view);
        if(bundle==null)
        {
            LocalBroadcastManager.getInstance(getActivity()).registerReceiver(nameChangeReceiver,filter);
         if(result==null)
          {
              result="china";
         }

        }
        else
        {
            result = bundle.getString("DATA");
        }
        ChangePhoto(result);
        return view;
    }
    public void onStop() {
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(nameChangeReceiver);
        super.onStop();
    }
    public void ChangePhoto(String photosrc)
    {
        img.setImageResource(getResources().getIdentifier(photosrc, "drawable", this.getActivity().getPackageName()));
        txt.setText(photosrc.substring(0, 1).toUpperCase()+result.substring(1).toLowerCase());
    }

    private class NameChangeReceiver extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent!=null)
            {
                result=intent.getStringExtra("flagname");
                ChangePhoto(result);
            }
        }
    }

}
