package com.example.mrtf.flagdemo;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class Main2Activity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        Intent intent = getIntent();
        String tag = intent.getStringExtra("flagname");

        Bundle bundle = new Bundle();
        bundle.putString("DATA",tag);

        Detail_Fragment fragment=new Detail_Fragment();
        fragment.setArguments(bundle);

        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.replace(R.id.line22, fragment);
        transaction.commit();


    }
}
