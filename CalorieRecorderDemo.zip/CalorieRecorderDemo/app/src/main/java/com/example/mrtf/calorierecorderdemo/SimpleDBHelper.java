package com.example.mrtf.calorierecorderdemo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SimpleDBHelper extends SQLiteOpenHelper {
    private static final String DBName = "CalorieDEMO.db";
    private static final String USER = "User";
    private static final String CREATE_USER_TABLE
            = "create table " + USER + "(id integer primary key autoincrement,datetime text,calorie integer)";


    public SimpleDBHelper(Context context, int version) {
        super(context, DBName, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        switch (i) {
            case 1:
                //upgrade logic from 1 to 2
                db.execSQL(CREATE_USER_TABLE);

            case 2:

                break;

            default:
                throw new IllegalStateException("unknown oldVersion " + i);
        }

    }
}
