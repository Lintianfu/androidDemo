package com.example.mrtf.calorierecorderdemo;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

public class EditActivity extends AppCompatActivity {

    private static SimpleDBHelper dbHelper;
    private  ListView listView;
    ArrayList<String> strArray;
    ArrayAdapter<String> adapter;
    SQLiteDatabase db;
    UserInfo user;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        initwith();
        isdelete();
    }
    public void query()
    {

        Cursor cursor=db.query("User",null,null,null,null,null,null);
        if(cursor.moveToFirst())
        {
            do {
                String date=cursor.getString(cursor.getColumnIndex("datetime"));
                int calurie=cursor.getInt(cursor.getColumnIndex("calorie"));
                String content=date+":"+String.valueOf(calurie);
                strArray.add(content);
            }while(cursor.moveToNext());
            cursor.close();
        }
    }
    public void initwith()
    {
        strArray=new ArrayList<>();
        dbHelper = new SimpleDBHelper(this, 5);
        dbHelper.getWritableDatabase();
        db=dbHelper.getWritableDatabase();
        listView = (ListView) findViewById(R.id.list);
        query();
        creat_list();
    }
    public void creat_list()
    {
        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, strArray);
        listView.setAdapter(adapter);
    }
    public void isdelete()
    {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id)
            {
                String item = parent.getItemAtPosition(position).toString();
                String[] parts = item.split(":");
                final String parts_one=parts[0];

                AlertDialog.Builder builder=new AlertDialog.Builder(EditActivity.this);
                builder.setTitle("Delete Item Dialog");
                builder.setMessage("Are you sure to delete this record?");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        db.delete("User","datetime=?",new String[]{parts_one});
                        initwith();
                    }
                });
                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                AlertDialog alert=builder.create();
                alert.show();
                return false;
            }
        });
    }

    public void click(View v)
    {
        if(v.getId()==R.id.add_btn)
        {
            Intent intent=new Intent(this,UpdateActivity.class);
            startActivity(intent);
        }
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        initwith();
    }
}
