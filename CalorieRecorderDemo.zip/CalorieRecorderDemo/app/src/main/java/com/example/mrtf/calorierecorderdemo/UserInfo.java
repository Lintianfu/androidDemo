package com.example.mrtf.calorierecorderdemo;

import java.util.Date;

public class UserInfo {
    public String time;
    public int calories;

    public void setCalories(int calories) {
        this.calories = calories;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTime() {
        return time;
    }

    public int getCalories() {
        return calories;
    }
}
