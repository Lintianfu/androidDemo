package com.example.mrtf.calorierecorderdemo;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class UpdateActivity extends AppCompatActivity {

    private static SimpleDBHelper dbHelper;
    CalendarView mCalendarView;
    TextView t;
    String datat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        dbHelper = new SimpleDBHelper(this, 5);
        dbHelper.getWritableDatabase();
        initwith();
        chooseCalender();

    }
    public void initwith()
    {
        mCalendarView=(CalendarView)findViewById(R.id.calendarView);
        t=(TextView)findViewById(R.id.show);
        Calendar calender = Calendar.getInstance();
        datat = calender.get(Calendar.YEAR) + "-" + (calender.get(Calendar.MONTH)+1)
                + "-" + calender.get(Calendar.DAY_OF_MONTH);
        t.setText(datat);
    }
    private void chooseCalender() {
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                datat = year + "-" + ((month + 1) < 10 ? "0" + (month + 1) : (month + 1)) + "-" + (dayOfMonth < 10 ? "0" + dayOfMonth : dayOfMonth);
                t.setText(datat);
            }
        });
    }
    public void updateclick(View v)
    {
        EditText exit_calorie=(EditText)findViewById(R.id.update_view);
        if(v.getId()==R.id.update_button)
        {
            String datetime= (String) t.getText();
            String calorie=exit_calorie.getText().toString();
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("datetime", (String) t.getText());
            values.put("calorie", Integer.parseInt(exit_calorie.getText().toString()));

            db.insert("User", null, values);
            exit_calorie.setText(" ");

        }
    }
}
