package com.example.mrtf.calorierecorderdemo;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.helper.DateAsXAxisLabelFormatter;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
public class MainActivity extends AppCompatActivity {

    private static SimpleDBHelper dbHelper;
    SQLiteDatabase db;
    ArrayList<UserInfo> userArray;
    ArrayList<DataPoint> datepointArray;
    UserInfo user;
    private String date_one;
    private String date_two;
    Calendar calender = Calendar.getInstance();
    private GraphView graph;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initWithView();

    }
    public void initWithView()
    {
        dbHelper = new SimpleDBHelper(this, 5);
        db=dbHelper.getWritableDatabase();
        dbHelper.getWritableDatabase();
        userArray=new ArrayList<>();
        datepointArray=new ArrayList<>();
        query();
        initWithDatapoint();
        initWithGraphview();
    }
    public void initWithDatapoint()
    {
        for(int i=0;i<userArray.size();i++)
        {
            SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
            try {
                Date date = sf.parse(userArray.get(i).time);
                datepointArray.add(new DataPoint(date, userArray.get(i).calories));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }
    public void initWithGraphview()
    {
        LineGraphSeries<DataPoint> series;
        graph= (GraphView) findViewById(R.id.graph);
        DataPoint[] dp=new DataPoint[]{};
        dp=datepointArray.toArray(dp);
        series=new LineGraphSeries<DataPoint>(dp);
        graph.addSeries(series);
        graph.getGridLabelRenderer().setLabelFormatter(new DateAsXAxisLabelFormatter(this));
        graph.getGridLabelRenderer().setNumHorizontalLabels(datepointArray.size());
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getGridLabelRenderer().setHumanRounding(false);

    }
    public void query_between()
    {
      String sql="select * from User where strftime('%s',datetime) >= strftime('%s',?) and strftime('%s',datetime)<=strftime('%s',?)";
      Cursor cursor = db.rawQuery(sql,new String[]{date_one, date_two});
        if(cursor.moveToFirst())
        {
            do {
                String date=cursor.getString(cursor.getColumnIndex("datetime"));
                int calurie=cursor.getInt(cursor.getColumnIndex("calorie"));
                user=new UserInfo();
                user.time=date;
                user.calories=calurie;
                userArray.add(user);
            }while(cursor.moveToNext());
            cursor.close();
        }

    }
    public void query() {

        Cursor cursor=db.query("User",null,null,null,null,null,null);
        if(cursor.moveToFirst())
        {
            do {
                String date=cursor.getString(cursor.getColumnIndex("datetime"));
                int calurie=cursor.getInt(cursor.getColumnIndex("calorie"));
                user=new UserInfo();
                user.time=date;
                user.calories=calurie;
                userArray.add(user);
            }while(cursor.moveToNext());
            cursor.close();
        }
    }
    public void click(View v)
    {
        final TextView begin=(TextView)findViewById(R.id.begin_click);
        final TextView end=(TextView)findViewById(R.id.end_click);
        int resi=v.getId();
        switch (resi)
        {

            case R.id.edit_btn:
                Intent intent=new Intent(this,EditActivity.class);
                startActivityForResult(intent,0);
                break;
            case R.id.query_btn:
                graph.removeAllSeries();
                userArray.clear();
                datepointArray.clear();
                if(flag()==1)
                {
                    query_between();
                    initWithDatapoint();
                    SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
                    try {
                        graph.getViewport().setMinX(sf.parse(date_one).getTime());
                        graph.getViewport().setMaxX(sf.parse(date_two).getTime());
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    initWithGraphview();
                }
                Toast.makeText(MainActivity.this,"查询日期输入错误",Toast.LENGTH_LONG).show();
                break;
            case R.id.begin_click:
                DatePickerDialog dialog = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        calender.set(year, monthOfYear, dayOfMonth);
                        begin.setText(DateFormat.format("yyyy-MM-dd", calender));
                        date_one=(String)begin.getText();
                    }
                }, calender.get(Calendar.YEAR), calender.get(Calendar.MONTH), calender.get(Calendar.DAY_OF_MONTH));
                dialog.show();
                break;
            case R.id.end_click:
                DatePickerDialog dialog1 = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        calender.set(year, monthOfYear, dayOfMonth);
                        end.setText(DateFormat.format("yyyy-MM-dd", calender));
                        date_two=(String)end.getText();
                    }
                }, calender.get(Calendar.YEAR), calender.get(Calendar.MONTH), calender.get(Calendar.DAY_OF_MONTH));
                dialog1.show();
                break;
                default:
                    break;
        }
    }
    public int flag() {
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date d1 = sf.parse(date_one);
            Date d2 = sf.parse(date_two);
            if (d1.getTime() < d2.getTime()) {
                return 1;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }
    protected void onRestart() {
        super.onRestart();
        initWithView();
    }
}
