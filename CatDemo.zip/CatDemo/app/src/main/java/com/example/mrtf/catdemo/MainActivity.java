package com.example.mrtf.catdemo;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import android.view.View;

import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import org.json.JSONArray;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {

    private TextView txt;
    private ImageView image;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onclick(View view)
    {
        if(view.getId()==R.id.btn){
            final GridLayout grid = (GridLayout) findViewById(R.id.grid);
            for(int i=0;i<3;i++)
                for(int j=0;j<3;j++) {
                     Ion.with(MainActivity.this)
                    .load("https://api.thecatapi.com/v1/images/search?")
                    .asString()
                    .setCallback(new FutureCallback<String>() {
                        @Override
                        public void onCompleted(Exception e, String result) {
                            String url=parseJSONWithJSONObject(result);
                            if(url!=null)
                            {
                                ImageView img=new ImageView(MainActivity.this);
                                Ion.with(MainActivity.this)
                                        .load(url)
                                        .intoImageView(img);
                                grid.addView(img);
                            }
                        }
                    });
                }
        }
    }
   private String parseJSONWithJSONObject(String jsonData)
    {
        try{
            JSONArray jsonArray=new JSONArray(jsonData);
            for (int i=0;i<jsonArray.length();i++)
            {
                JSONObject jsonObject=jsonArray.getJSONObject(i);
                String url=jsonObject.getString("url");
                return url;
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
}
