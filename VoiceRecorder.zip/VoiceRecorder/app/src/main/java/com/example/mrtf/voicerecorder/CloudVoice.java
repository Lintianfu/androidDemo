package com.example.mrtf.voicerecorder;

public class CloudVoice {
    private String name;
    private int header_imageId;
    private int paly_imageId;
    private String recodertime;
    private int exits;
    private int getduration;
    public CloudVoice(String name, int header_imageId,int paly_imageId,String recodertime,int exits,int getduration) {
        this.name = name;
        this.header_imageId = header_imageId;
        this.paly_imageId=paly_imageId;
        this.recodertime=recodertime;
        this.exits=exits;
        this.getduration=getduration;
    }

    public int getGetduration() {
        return getduration;
    }

    public void setGetduration(int getduration) {
        this.getduration = getduration;
    }

    public void setRecodertime(String recodertime)
    {
        this.recodertime=recodertime;
    }

    public String getRecodertime() {
        return recodertime;
    }

    public void setPaly_imageId(int paly_imageId) {
        this.paly_imageId = paly_imageId;
    }

    public int getPaly_imageId() {
        return paly_imageId;
    }

    public void setHeader_imageId(int header_imageId) {
        this.header_imageId = header_imageId;
    }

    public int getHeader_imageId() {
        return header_imageId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public int getExits() {
        return exits;
    }
    public void setExits(int exits)
    {
        this.exits=exits;
    }

}
