package com.example.mrtf.voicerecorder;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ModifyPWActivity extends AppCompatActivity {
    public Button sure_modify;
    public Button calcel_modify;
    public EditText password_edit;
    public EditText newpassword_edit;
    public EditText surepassword_edit;
    private static SimpleDBHelper dbHelper;
    public SQLiteDatabase db;
    private String username;
    private String oldpassword;
    private String newpassword;
    private String surepassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_pw);
        dbHelper = new SimpleDBHelper(this, 1);
        db=dbHelper.getWritableDatabase();
        username=query_username();
        InitWithView();
        sure_modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                oldpassword=password_edit.getText().toString();
                newpassword=newpassword_edit.getText().toString();
                surepassword=surepassword_edit.getText().toString();
                if(newpassword.equals(surepassword))
                {
                    Thread thread = new Thread(new Runnable(){
                        @Override
                        public void run(){
                           postFormModify(username,oldpassword,newpassword);
                        }
                    });
                    thread.start();
                }
                else {
                    Toast.makeText(ModifyPWActivity.this,"确认密码与新密码不一致，请重新输入",Toast.LENGTH_SHORT).show();
                    newpassword_edit.setText("");
                    surepassword_edit.setText("");
                }
                finish();

            }

        });
        calcel_modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
    public void InitWithView()
    {
        sure_modify=(Button)findViewById(R.id.sure_modify);
        calcel_modify=(Button)findViewById(R.id.cancel_modify);
        password_edit=(EditText)findViewById(R.id.edit_password);
        newpassword_edit=(EditText)findViewById(R.id.edit_newpassword);
        surepassword_edit=(EditText)findViewById(R.id.edit_surepassword);
    }
    public void postFormModify(String username_modify,String oldpassword_modify,String newpassword_modify) {
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("name", username_modify)
                .addFormDataPart("oldPwd", getDES(oldpassword_modify))
                .addFormDataPart("newPwd", getDES(newpassword_modify))
                .build();
        final Request request = new Request.Builder()
                .url("http://www.dgutguanyin.online/updatePwd")
                .post(requestBody)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
               Log.v("修改密码失败的原因",e.getLocalizedMessage());

            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseStr = response.body().string();
                Log.v("json",responseStr);
            }
        });
    }
    public String query_username()
    {

        Cursor cursor=db.query("LoginInformation",null,null,null,null,null,null);
        if(cursor.moveToFirst())
        {
            do {
                String name=cursor.getString(cursor.getColumnIndex("username"));
                return name;
            }while(cursor.moveToNext());
        }
        cursor.close();
        return null;
    }
    public String getDES(String DESpassword)
    {
        try {
            DesUtils des = new DesUtils("dgutguanyin"); //自定义密钥
            String DES_Password=des.encrypt(DESpassword);
            return DES_Password;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
