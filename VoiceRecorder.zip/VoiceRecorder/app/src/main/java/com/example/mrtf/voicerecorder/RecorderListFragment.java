package com.example.mrtf.voicerecorder;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class RecorderListFragment extends Fragment {
    protected View view;
    protected Context context;
    private ViewPager viewpager;
    private ArrayList<Fragment> listfragment;


    public RecorderListFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if(view==null){
            view=inflater.inflate(R.layout.fragment_recorder_list, null);
        }
        ViewGroup parent = (ViewGroup) view.getParent();
        if (parent != null) {
            parent.removeView(view);
        }

        context = getActivity();
        String desc = String.format("音频");
        TextView tv_list = (TextView)view.findViewById(R.id.tv_text);
        tv_list.setText(desc);

        viewpager=(ViewPager)view.findViewById(R.id.storage_viewpage);

        listfragment=new ArrayList<Fragment>();
        Fragment localStorageFragment = new LocalStorageFragment();
        Fragment cloudStorageFragment = new CloudStorageFragment();


        listfragment.add(localStorageFragment);
        listfragment.add(cloudStorageFragment);

        FragmentManager fm=getFragmentManager();
        StorageFragmentAdapter adapter = new StorageFragmentAdapter(getChildFragmentManager(), listfragment);
        viewpager.setAdapter(adapter);
        viewpager.setCurrentItem(0);
        return view;
    }

}
