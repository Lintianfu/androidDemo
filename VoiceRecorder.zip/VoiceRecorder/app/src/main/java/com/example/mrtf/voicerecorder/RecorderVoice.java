package com.example.mrtf.voicerecorder;

public class RecorderVoice {
    private String name;
    private int header_imageId;
    private int paly_imageId;
    private String voicetime;
    private String recodertime;
    private int getduration;
    private int isupload;
    public RecorderVoice(String name, int header_imageId,int paly_imageId,String voicetime,String recodertime,int getduration,int isupload) {
        this.name = name;
        this.header_imageId = header_imageId;
        this.voicetime=voicetime;
        this.paly_imageId=paly_imageId;
        this.recodertime=recodertime;
        this.getduration=getduration;
        this.isupload=isupload;
    }

    public void setIsupload(int isupload) {
        this.isupload = isupload;
    }

    public int getIsupload() {
        return isupload;
    }
    public int getGetduration() {
        return getduration;
    }
    public void setGetduration(int getduration)
    {
        this.getduration=getduration;
    }

    public void setRecodertime(String recodertime)
    {
        this.recodertime=recodertime;
    }

    public String getRecodertime() {
        return recodertime;
    }

    public void setVoicetime(String voicetime) {
        this.voicetime = voicetime;
    }

    public String getVoicetime() {
        return voicetime;
    }

    public void setPaly_imageId(int paly_imageId) {
        this.paly_imageId = paly_imageId;
    }

    public int getPaly_imageId() {
        return paly_imageId;
    }

    public void setHeader_imageId(int header_imageId) {
        this.header_imageId = header_imageId;
    }

    public int getHeader_imageId() {
        return header_imageId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
