package com.example.mrtf.voicerecorder;

import android.annotation.SuppressLint;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.LocalActivityManager;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.kaopiz.kprogresshud.KProgressHUD;

import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class TabFragmentActivity extends FragmentActivity {
    private FragmentTabHost mTabHost;
    private static SimpleDBHelper dbHelper;
    private SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab_fragment);
        ActivityManager.getInstance().addActivity(this);
        dbHelper = new SimpleDBHelper(this, 1);
        db=dbHelper.getWritableDatabase();

        mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        mTabHost.setup(TabFragmentActivity.this, getSupportFragmentManager(), R.id.realtabcontent);
        DisplayFragment();
        mTabHost.getTabWidget().setShowDividers(LinearLayout.SHOW_DIVIDER_NONE);
    }

    private Handler handler = new Handler(){
        @SuppressLint("ResourceAsColor")
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    AlertDialog dialog=new AlertDialog.Builder(TabFragmentActivity.this).setTitle("登录已过期！")
                            .setMessage("请重新登录")
                            .setIcon(android.R.drawable.sym_def_app_icon)
                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Intent intenttologin=new Intent(TabFragmentActivity.this,LoginActivity.class);
                                    startActivity(intenttologin);
                                }
                            }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ContentValues values = new ContentValues();
                            values.put("token", "loginout");
                            values.put("username","用户名");
                            db.update("LoginInformation", values, "id=?", new String[]{"1"});
                        }
                    }).show();
                    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(R.color.colorPrimaryDark);
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(R.color.colorPrimaryDark);
                    break;
            }
        }
    };
    public String query_token()
    {
        Cursor cursor=db.query("LoginInformation",null,null,null,null,null,null);
        if(cursor.moveToFirst())
        {
            do {
                String token=cursor.getString(cursor.getColumnIndex("token"));
                return token;
            }while(cursor.moveToNext());
        }
        cursor.close();
        return null;
    }
    public void DisplayFragment()
    {

        mTabHost.addTab(getTabView(R.string.menu_first, R.drawable.tab_first_selector),
                RecorderFragment.class, null);
        mTabHost.addTab(getTabView(R.string.menu_second, R.drawable.tab_second_selector),
                RecorderListFragment.class, null);
        mTabHost.addTab(getTabView(R.string.menu_third, R.drawable.tab_third_selector),
                MyisloginFragment.class, null);
        final String tokeninfo=query_token();
        if(tokeninfo!=null&&!tokeninfo.equals("loginout"))
        {
            Thread thread = new Thread(new Runnable(){
                @Override
                public void run(){
                    postLoginStatus(tokeninfo);
                }
            });
            thread.start();
        }
       /* mTabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {
                if(tabId.equals("我的"))
                {
                    String tokeninfomation=query_token();
                    if(tokeninfomation==null||tokeninfomation.equals("loginout"))
                    {
                        Intent intenttologin=new Intent(TabFragmentActivity.this,LoginActivity.class);
                        startActivity(intenttologin);
                    }
                }
            }
        });*/
    }
   public void postLoginStatus(String tokennowinfo) {

        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("token", tokennowinfo)
                .build();
        final Request request = new Request.Builder()
                .url("http://www.dgutguanyin.online/checkLogin")
                .post(requestBody)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseStr = response.body().string();
                parseJSONWithJSONObject(responseStr);
            }
        });
    }
    public void parseJSONWithJSONObject(String JsonData) {
        try
        {
            JSONObject jsonObject=new JSONObject(JsonData);
            int status=jsonObject.getInt("status");
            if(status==-1)
            {
                Message msg =Message.obtain();
                msg.what=1;
                handler.sendMessage(msg);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    public void getLoginStatus(String status)
    {
        if(status.equals("YES"))
        {
            ActivityManager.getInstance().exit();
        }
    }
    public void onResume() {
        super.onResume();
    }
    protected void onDestroy() {
        super.onDestroy();
        db.close();
    }
    private TabHost.TabSpec getTabView(int textId, int imgId) {
        String text = getResources().getString(textId);
        Drawable drawable = getResources().getDrawable(imgId);
        drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
        View item_tabbar = getLayoutInflater().inflate(R.layout.item_tabbar, null);
        TextView tv_item = (TextView) item_tabbar.findViewById(R.id.tv_item_tabbar);
        tv_item.setText(text);
        tv_item.setCompoundDrawables(null, drawable, null, null);
        TabHost.TabSpec spec = mTabHost.newTabSpec(text).setIndicator(item_tabbar);
        return spec;
    }

}

