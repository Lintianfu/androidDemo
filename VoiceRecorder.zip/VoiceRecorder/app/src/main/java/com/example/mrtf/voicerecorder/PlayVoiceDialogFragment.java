package com.example.mrtf.voicerecorder;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import java.util.Timer;


/**
 * A simple {@link Fragment} subclass.
 */
public class PlayVoiceDialogFragment extends DialogFragment {

    private SeekBar seekBar;
    private View view;
    private ImageButton finishi;
    public TextView voicename;
    public int itemtime;
    public String itemname;
    public PlayVoiceDialogFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
         view=inflater.inflate(R.layout.fragment_play_voice_dialog, container, false);
         seekBar = (SeekBar) view.findViewById(R.id.seekBar);
         finishi=(ImageButton)view.findViewById(R.id.Button02);
         voicename=(TextView)view.findViewById(R.id.textname);

         Bundle bundle = getArguments();
         if (bundle != null) {
            itemtime = bundle.getInt("itemtime");
            itemname=bundle.getString("itemname");
         }
         voicename.setText(itemname);
        seekBar.setMax(itemtime);
          new Thread(new Runnable() {
            @Override
            public void run() {
                int i = 1;
                while (i <=itemtime+1) {
                    try {
                        Thread.sleep(1000);
                        seekBar.setProgress(i);
                        i++;
                    } catch (Exception e) {
                    }
                }
            }
        }).start();
         seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
         finishi.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent intent = new Intent(getActivity(), MyService.class);
                 Bundle bundle = new Bundle();
                 bundle.putSerializable("Key", MyService.Control.STOP);
                 bundle.putString("voicepath","");
                 intent.putExtras(bundle);
                 getActivity().startService(intent);
                 dismiss();
             }
         });
        return view;
    }
    public void onResume() {
        super.onResume();
        Window mWindow = getDialog().getWindow();
        WindowManager.LayoutParams mLayoutParams = mWindow.getAttributes();
        mLayoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
        mLayoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        mWindow.setAttributes(mLayoutParams);
    }
    public void onDestroy() {
        super.onDestroy();
        dismiss();
    }
}
