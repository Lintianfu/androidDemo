package com.example.mrtf.voicerecorder;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.IntDef;
import android.util.Log;
import android.widget.Toast;
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX;
import com.tencent.mm.opensdk.modelmsg.WXImageObject;
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage;
import com.tencent.mm.opensdk.modelmsg.WXMusicObject;
import com.tencent.mm.opensdk.modelmsg.WXTextObject;
import com.tencent.mm.opensdk.modelmsg.WXVideoObject;
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import static com.example.mrtf.voicerecorder.WxShareTo.share_favorite;
import static com.example.mrtf.voicerecorder.WxShareTo.share_session;
import static com.example.mrtf.voicerecorder.WxShareTo.share_timeline;
import static com.example.mrtf.voicerecorder.WxShareType.type_image;
import static com.example.mrtf.voicerecorder.WxShareType.type_music;
import static com.example.mrtf.voicerecorder.WxShareType.type_text;
import static com.example.mrtf.voicerecorder.WxShareType.type_video;
import static com.example.mrtf.voicerecorder.WxShareType.type_webPage;

@IntDef({ share_session, share_timeline, share_favorite })
@Retention(RetentionPolicy.SOURCE)
@interface WxShareTo {
    int share_session = SendMessageToWX.Req.WXSceneSession;
    int share_favorite = SendMessageToWX.Req.WXSceneFavorite;
    int share_timeline = SendMessageToWX.Req.WXSceneTimeline;
}
@IntDef ({ type_text, type_image, type_video, type_music,type_webPage})
@Retention (RetentionPolicy.SOURCE)
@interface WxShareType {

    int type_text = 0;
    int type_image = 1;
    int type_video = 2;
    int type_music = 3;
    int type_webPage=4;
}
public class WeChatShare {
    private static IWXAPI iwxapi;
    private static Context mContext;
    private int share_to = share_session;
    private int share_type = -1;
    private String url = "";
    private String title = "";
    private String description = "";
    private String shareText = "";
    private Bitmap imageBitmap = null;
    private String miniProgramId = "";
    private String miniProgramPath = "";
    private static  String APP_ID = "wxed71bcc06c869d92";
    public static WeChatShare regToWx(Context context) {
        mContext = context;
        iwxapi = WXAPIFactory.createWXAPI(context, APP_ID, false);
        boolean flag = iwxapi.registerApp(APP_ID);
        Toast.makeText(context, "flag:" + flag, Toast.LENGTH_SHORT).show();
        return new WeChatShare();
    }

    public WeChatShare setWhere(@WxShareTo int shareTo) {
        share_to = shareTo;
        return this;
    }

    public WeChatShare setType(@WxShareType int type) {
        share_type = type;
        return this;
    }

    public WeChatShare addUrl(String url) {
        this.url = url;
        return this;
    }
    public WeChatShare addTitle(String title) {
        this.title = title;
        return this;
    }
    public WeChatShare addDescription(String description) {
        this.description = description;
        return this;
    }
    public WeChatShare addImage(String imageUrl) {
        addImage(BitmapUtils.getBitmap(imageUrl));
        return this;
    }
    public WeChatShare addImage(int imageResource) {
        addImage(BitmapFactory.decodeResource(mContext.getResources(), imageResource));
        return this;
    }

    public WeChatShare addImage(Bitmap imageBitmap) {
        this.imageBitmap = imageBitmap;
        return this;
    }

    public WeChatShare addShareText(String shareText) {
        this.shareText = shareText;
        return this;
    }


    public void share(RecorderVoice recorderVoice,String username) {
        WXMediaMessage msg = new WXMediaMessage();
        imageBitmap=BitmapFactory.decodeResource(Resources.getSystem(), R.drawable.music);
        msg.title=recorderVoice.getName().substring(36);
        msg.description=username;
        if (null != imageBitmap) {
            Bitmap bmp = Bitmap.createScaledBitmap(imageBitmap, 80, 80, true);
            imageBitmap.recycle();
            msg.thumbData = BitmapUtils.Bitmap2Bytes(bmp);
        }
        String transaction = "";
        switch (share_type) {
            case type_text:
                transaction = "text";
                msg.description = shareText;
                WXTextObject textObject = new WXTextObject();
                textObject.text = shareText;
                msg.mediaObject = textObject;
                break;
            case type_image:
                transaction = "img";
                if (null == imageBitmap) {
                    throw new NullPointerException("bitmap is null.");
                }
                msg.mediaObject = new WXImageObject(imageBitmap);
                break;
            case type_music:
                transaction = "music";
                WXMusicObject musicObject = new WXMusicObject();
                musicObject.musicUrl = url;
                msg.mediaObject = musicObject;
                break;
            case type_webPage:
                transaction = "webpage";
                WXWebpageObject webpageObject = new WXWebpageObject();
                webpageObject.webpageUrl = url;
                msg.mediaObject = webpageObject;
                break;

           default:
               break;
        }

        sendMsg(msg, transaction);
    }

    private void sendMsg(WXMediaMessage mediaMessage, String transaction) {
        if (!AppUtils.getInstance(mContext).isAppAvilible(AppUtils.WX_PKGNAME)) {
            Toast.makeText(mContext, "您还未安装微信客户端，请先安装.", Toast.LENGTH_SHORT).show();
            return;
        }
        SendMessageToWX.Req req = new SendMessageToWX.Req();
        req.transaction = buildTransaction(transaction);
        req.message = mediaMessage;
        req.scene = share_to;
        iwxapi.sendReq(req);
    }

    private String buildTransaction(String type) {
        return (type == null) ? String.valueOf(System.currentTimeMillis()) : type + System.currentTimeMillis();
    }

}

