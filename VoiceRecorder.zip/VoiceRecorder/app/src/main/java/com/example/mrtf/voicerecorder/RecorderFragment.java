package com.example.mrtf.voicerecorder;
import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.kaopiz.kprogresshud.KProgressHUD;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import jaygoo.widget.wlv.WaveLineView;


/**
 * A simple {@link Fragment} subclass.
 */
public class RecorderFragment extends Fragment {

    protected View view;
    protected Context context;
    private ImageButton record_btn,play_btn;
    private TextView text_waring;
    private TextView recorded_audio_time;
    private boolean mPlaying = true;
    private boolean mRecording = true;
    private MediaRecorder mAudioRecorder;
    private File mAudioFile;
    private String mFilePath=null;
    private File newFile;
    private Timer mRecordingtimer,mPlayingTimer1;
    private int seconds,second;
     private static SimpleDBHelper dbHelper;
    private String tempFilePath;
    private ExecutorService mExecutorService;
    private SimpleDateFormat formatter;
    private WaveLineView waveLineView;
    public RecorderFragment() {
        // Required empty public constructor

    }

    @RequiresApi(api = 28)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        if(view==null){
            view=inflater.inflate(R.layout.fragment_recorder, null);
        }
        ViewGroup parent = (ViewGroup) view.getParent();
        if (parent != null) {
            parent.removeView(view);
        }
        context = getActivity();
        dbHelper = new SimpleDBHelper(getActivity(), 1);
        mExecutorService = Executors.newFixedThreadPool(2);
        int MyVersion = Build.VERSION.SDK_INT;
        if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
            if (!checkIfAlreadyhavePermission()) {
                requestForSpecificPermission();
            }
        }
        waveLineView = (WaveLineView)view.findViewById(R.id.waveLineView);
        String desc = String.format("录音");
        TextView tv_recoder = (TextView)view.findViewById(R.id.tv_text);
        text_waring=(TextView) view.findViewById(R.id.option_waring);
        recorded_audio_time=(TextView)view.findViewById(R.id.time_recorder);
        tv_recoder.setText(desc);

        record_btn = (ImageButton)view.findViewById(R.id.record_btn);
        play_btn=(ImageButton)view.findViewById(R.id.play_pause_btn);
        play_btn.setEnabled(false);

        record_btn.setOnClickListener(new View.OnClickListener() {
       // @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                recordAudio();
            }
        });
        play_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playAudio();
            }
        });
        return view;
    }

    private boolean checkIfAlreadyhavePermission() {
        int result = ContextCompat.checkSelfPermission(context, Manifest.permission.GET_ACCOUNTS);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    @RequiresApi(api = 28)
    private void requestForSpecificPermission() {
        ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.GET_ACCOUNTS, Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS, Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.RECORD_AUDIO,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.FOREGROUND_SERVICE,Manifest.permission.INTERNET,Manifest.permission.READ_PHONE_STATE}, 101);
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 101:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {

                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
    private void recordAudio() {
        if (mRecording) {
            mRecording = false;
            waveLineView.startAnim();
            text_waring.setText("正在录音......");
            mFilePath=Environment.getExternalStorageDirectory().getAbsolutePath() + "/AudioRecordDemo/" + "Audio";
            tempFilePath = mFilePath+getCurrenttime("filename")+".m4a";
            mExecutorService.execute(new Runnable() {
                @Override
                public void run() {
                    startRecording();
                }
            });
            showTimeforRecorder();
            record_btn.setImageResource(R.drawable.pause);
        } else {
            stopRecording();
            waveLineView.stopAnim();
            text_waring.setText("录音完成");
            record_btn.setImageResource(R.drawable.start);
            mRecording = true;
            mRecordingtimer.cancel();
            recorded_audio_time.setText("00:00");
            play_btn.setEnabled(true);
        }
    }
    public void Play_Service()
    {
        Intent intent = new Intent(getActivity(), MyService.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("Key", MyService.Control.PLAY);
        bundle.putString("voicepath",newFile.getAbsolutePath());
        intent.putExtras(bundle);
        getActivity().startService(intent);
    }
    public void Stop_Service()
    {
        Intent intent = new Intent(getActivity(), MyService.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("Key", MyService.Control.STOP);
        bundle.putString("voicepath","");
        intent.putExtras(bundle);
        getActivity().startService(intent);
    }
    private void playAudio() {
        if (mPlaying) {
            record_btn.setEnabled(false);
            waveLineView.startAnim();
            text_waring.setText("正在播放录音......");
            mPlaying=false;
            Play_Service();
            showProgressforPlaying();
            play_btn.setImageResource(R.drawable.isplay);
            mPlaying = false;
        } else {
            Stop_Service();
            waveLineView.stopAnim();
            text_waring.setText("选择录音或者播放");
            play_btn.setImageResource(R.drawable.play);
            recorded_audio_time.setText("00:00");
            mPlayingTimer1.cancel();
            mPlaying = true;
            record_btn.setEnabled(true);
        }
    }
    private void startRecording() {
        mAudioRecorder = new MediaRecorder();
        mAudioFile=new File(tempFilePath);
        mAudioFile.getParentFile().mkdirs();
        try {
            mAudioFile.createNewFile();
            mAudioRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mAudioRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4 );
            mAudioRecorder.setOutputFile(mAudioFile.getAbsolutePath());
            mAudioRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            try {
                mAudioRecorder.prepare();
            } catch (IOException e) {
                e.printStackTrace();
            }
            mAudioRecorder.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @SuppressLint("ResourceAsColor")
    private void stopRecording() {
        if (mAudioRecorder != null) {
            try {
                mAudioRecorder.stop();
            } catch (IllegalStateException e) {
                mAudioRecorder = null;
                mAudioRecorder = new MediaRecorder();
            }
            mAudioRecorder.release();
            mAudioRecorder = null;
        }
        final EditText et = new EditText(context);
        AlertDialog dialog=new AlertDialog.Builder(context).setTitle("请输入录音文件名")
                .setIcon(R.mipmap.ic_launcher)
                .setView(et)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        chageFileName(tempFilePath, String.valueOf(et.getText()));
                        SQLiteDatabase db = dbHelper.getWritableDatabase();
                        ContentValues values = new ContentValues();
                        values.put("voicepath", newFile.getAbsolutePath());
                        values.put("voicetime", TimerUtils.getTime(seconds));
                        values.put("recordertime",getCurrenttime("filetime"));
                        values.put("getduration",seconds);
                        values.put("isupload",0);
                        db.insert("VoiceRecorder", null, values);
                    }
                }).show();
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(R.color.colorPrimaryDark);
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(R.color.colorPrimaryDark);


    }
    public void chageFileName(String filePath,String reName){
        File file = new File(filePath);
        String path = filePath.substring(0, filePath.lastIndexOf("/")+1)+reName+filePath.substring(filePath.lastIndexOf("."), filePath.length());
        newFile = new File(path);
        file.renameTo(newFile);
    }
    public String getCurrenttime(String function)
    {
        long currentTime = System.currentTimeMillis();
        if(function.equals("filetime"))
        {
            formatter = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
        }
        else {
            formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        }
        Date date = new Date(currentTime);
        String time=formatter.format(date);
        return time;
    }
    private void showTimeforRecorder() {
        seconds = 0;
        mRecordingtimer = new Timer();
        mRecordingtimer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (!mRecording) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            seconds++;
                            recorded_audio_time.setText(TimerUtils.getTime(seconds));
                        }
                    });
                }
            }
        }, 1000, 1000);
    }
    private void showProgressforPlaying() {
        second = 0;
        mPlayingTimer1 = new Timer();
        mPlayingTimer1.schedule(new TimerTask() {
            @Override
            public void run() {
                if (!mPlaying) {
                   getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if(second<seconds)
                            {
                                second++;
                                recorded_audio_time.setText(TimerUtils.getTime(second));
                            }
                            else
                            {
                               playAudio();
                            }

                        }
                    });
                }
            }
        }, 1000, 1000);
    }

    public void onDestroy() {
        super.onDestroy();
        waveLineView.release();
    }
}
