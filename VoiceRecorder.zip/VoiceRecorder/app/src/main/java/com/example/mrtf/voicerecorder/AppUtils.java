package com.example.mrtf.voicerecorder;


import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import java.util.List;

public class AppUtils {
    public static AppUtils instance;
    public static Context mContext;
    public static final String QQ_PKGNAME = "com.tencent.mobileqq";
    public static final String WX_PKGNAME = "com.tencent.mm";

    public static AppUtils getInstance(Context context) {
        mContext = context;
        if (null == instance) {
            synchronized (AppUtils.class) {
                if (null == instance) {
                    instance = new AppUtils();
                }
            }
        }
        return instance;
    }

    public boolean isAppAvilible(String pkgName) {
        final PackageManager packageManager = mContext.getPackageManager();
        List<PackageInfo> pinfo = packageManager.getInstalledPackages(0);
        if (pinfo != null) {
            for (int i = 0; i < pinfo.size(); i++) {
                String pn = pinfo.get(i).packageName;
                if (pn.equals("com.tencent.mm")) {
                    return true;
                }
            }
        }
        return false;
    }

}
