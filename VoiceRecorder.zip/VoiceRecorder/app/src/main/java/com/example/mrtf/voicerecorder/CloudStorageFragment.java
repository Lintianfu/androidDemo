package com.example.mrtf.voicerecorder;


import android.annotation.SuppressLint;
import android.content.ContentValues;;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.ListFragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.kaopiz.kprogresshud.KProgressHUD;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class CloudStorageFragment extends ListFragment {
    private View view;
    private static SimpleDBHelper dbHelper;
    public SQLiteDatabase db;
    private ListView listView;
    private CloudVoiceAdapter adapter;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ArrayList<CloudVoice> cloudVoiceslist=new ArrayList<>();
    public String mkdirpath="/storage/emulated/0/AudioRecordDemo/";
    public String voicename;
    private String username;
    public PlayVoiceDialogFragment playVoiceDialogFragment;
    private KProgressHUD hud;
    public CloudStorageFragment() {

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_cloud_storage, container, false);
        listView=view.findViewById(android.R.id.list);
        dbHelper = new SimpleDBHelper(getActivity(), 1);
        db=dbHelper.getWritableDatabase();
        username=query_username();
        swipeRefreshLayout=(SwipeRefreshLayout)view.findViewById(R.id.swipe_container);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            public void onRefresh() {
                Thread thread = new Thread(new Runnable(){
                    @Override
                    public void run(){
                        postFormCloud();
                    }
                });
                thread.start();
                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        initWithVoice();
                        swipeRefreshLayout.setRefreshing(false);
                    }
                }, 2000);
            }
        });
        return view;
    }

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    hud=KProgressHUD.create(getActivity())
                            .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                            .setLabel("正在下载...")
                            .setCancellable(false)
                            .setAnimationSpeed(2)
                            .setDimAmount(0.5f)
                            .show();
                    break;
                case 2:
                    Toast.makeText(getContext(),"音频文件下载成功",Toast.LENGTH_SHORT).show();
                    hud.dismiss();
                    Intent intent2 = new Intent("MainActivitytofragment");
                    LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(intent2);
                    break;
                case 3:
                    hud.dismiss();
                    Toast.makeText(getContext(),"音频文件下载失败",Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    public String query_username() //获取用户名
    {
            Cursor cursor=db.query("LoginInformation",null,null,null,null,null,null);
            if(cursor.moveToFirst())
            {
                do {
                    String name=cursor.getString(cursor.getColumnIndex("username"));
                    return name;
                }while(cursor.moveToNext());
            }
            cursor.close();
            return null;
    }

    public String query_token() //获取token信息
    {
        Cursor cursor=db.query("LoginInformation",null,null,null,null,null,null);
        if(cursor.moveToFirst())
        {
            do {
                String token=cursor.getString(cursor.getColumnIndex("token"));
                return token;
            }while(cursor.moveToNext());
        }
        cursor.close();
        return null;
    }
    public void postFormCloud() {

        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("name", username)
                .build();
        final Request request = new Request.Builder()
                .url("http://www.dgutguanyin.online/getFileList")
                .post(requestBody)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseStr = response.body().string();
                parseJSONWithJSONObject(responseStr);
            }
        });
    }
    private void parseJSONWithJSONObject(String jsonData)
    {
        try{
            JSONArray jsonArray=new JSONArray(jsonData);
            for (int i=0;i<jsonArray.length();i++)
            {
                JSONObject jsonObject=jsonArray.getJSONObject(i);
                String filename=jsonObject.getString("fileName");
                String filepath=jsonObject.getString("filePath");
                String createdate=jsonObject.getString("createDate");
                int getduration=jsonObject.getInt("time");
                Cursor cursor=db.query("CloudRecorder",new String[]{"fileName"},"fileName=?",new String[]{filename},null,null,null);
                if(cursor.getCount()==0)
                {
                    ContentValues values = new ContentValues();
                    values.put("fileName", filename);
                    values.put("filePath", filepath);
                    values.put("createDate",createdate);
                    String directory="/storage/emulated/0/AudioRecordDemo/";
                    Cursor cursor1=db.query("VoiceRecorder",new String[]{"voicepath"},"voicepath=?",new String[]{directory+filename},null,null,null);
                    if(cursor1.getCount()==0)
                    {
                        values.put("exits",0);
                    }
                    else
                    {
                        values.put("exits",1);
                    }
                    values.put("getduration",getduration);
                    values.put("user",username);
                    db.insert("CloudRecorder", null, values);
                }
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    public void query_all()
    {
        Cursor cursor=db.query("CloudRecorder",null,null,null,null,null,null);
        if(cursor.moveToFirst())
        {
            do {
                String fileName=cursor.getString(cursor.getColumnIndex("fileName"));
                String filePath=cursor.getString(cursor.getColumnIndex("filePath"));
                String createDate=cursor.getString(cursor.getColumnIndex("createDate"));
                int getduration=cursor.getInt(cursor.getColumnIndex("getduration"));
                int exits=cursor.getInt(cursor.getColumnIndex("exits"));
                String user=cursor.getString(cursor.getColumnIndex("user"));
                if(user.equals(username))
                {
                    if(exits==0)
                    {
                        CloudVoice cloudVoice=new CloudVoice(fileName,getResources().getIdentifier("music", "drawable", this.getActivity().getPackageName()),getResources().getIdentifier("download_small", "drawable", this.getActivity().getPackageName()),createDate.substring(0,19),0,getduration);
                        cloudVoiceslist.add(cloudVoice);
                    }
                    else
                    {
                        CloudVoice cloudVoice=new CloudVoice(fileName,getResources().getIdentifier("music", "drawable", this.getActivity().getPackageName()),getResources().getIdentifier("play_small", "drawable", this.getActivity().getPackageName()),createDate.substring(0,19),1,getduration);
                        cloudVoiceslist.add(cloudVoice);
                    }
                }
            }while(cursor.moveToNext());
            cursor.close();
        }
    }
    public void initWithVoice()
    {
        cloudVoiceslist.clear();
        query_all();
        adapter= new CloudVoiceAdapter(this.getActivity(),R.layout.cloudvoice_item,cloudVoiceslist);
        listView.setAdapter(adapter);
        adapter.setOnClickImagbutton(new CloudVoiceAdapter.onClickImagbutton() {
            public void ImagbuttonClick(final CloudVoice cloudVoice, final int position) {

                String sql =" select * from CloudRecorder where fileName=?";
                Cursor cursor = db.rawQuery(sql, new String[]{cloudVoice.getName()});
                int exits=-1;
                while (cursor.moveToNext()) {
                      exits= cursor.getInt(cursor.getColumnIndex("exits"));
                }
                if(exits==0)
                {
                    Thread thread = new Thread(new Runnable(){
                        @Override
                        public void run(){
                            Message msg =Message.obtain();
                            msg.what=1;
                            handler.sendMessage(msg);

                            DownloadUtil.get().download(username,cloudVoice.getName(), new DownloadUtil.OnDownloadListener() {
                                public void onDownloadSuccess(String path) {

                                    Message msg =Message.obtain();
                                    msg.what=2;
                                    handler.sendMessage(msg);

                                    int seconds=cloudVoice.getGetduration();
                                    ContentValues values = new ContentValues();
                                    values.put("voicepath", path);
                                    values.put("voicetime",TimerUtils.getTime(seconds));
                                    values.put("recordertime",getCurrenttime());
                                    values.put("getduration",seconds);
                                    values.put("isupload",1);
                                    db.insert("VoiceRecorder", null, values);
                                    String sql="update CloudRecorder set exits=1 where fileName=?";
                                    db.execSQL(sql,new String[]{cloudVoice.getName()});
                                    adapter.update(position,listView);

                                }
                                @Override
                                public void onDownloading(int progress) {

                                }
                                @Override
                                public void onDownloadFailed() {
                                    Message msg =Message.obtain();
                                    msg.what=3;
                                    handler.sendMessage(msg);
                                }
                            });
                        }
                    });
                    thread.start();
                }
                else {
                    voicename=cloudVoice.getName();
                    Intent intent = new Intent(getActivity(), MyService.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("Key", MyService.Control.PLAY);
                    bundle.putString("voicepath",mkdirpath+voicename);
                    intent.putExtras(bundle);
                    getActivity().startService(intent);
                    Thread thread = new Thread(new Runnable(){
                        @Override
                        public void run(){
                            FragmentManager fragmentManager=getFragmentManager();
                            playVoiceDialogFragment=new PlayVoiceDialogFragment();
                            Bundle bundle = new Bundle();
                            bundle.putInt("itemtime", cloudVoice.getGetduration());
                            bundle.putString("itemname",voicename);
                            playVoiceDialogFragment.setArguments(bundle);
                            playVoiceDialogFragment.show(fragmentManager,"delete_dlg");
                        }
                    });
                    thread.start();
                }
            }
        });
    }
    public String getCurrenttime()
    {
        long currentTime = System.currentTimeMillis();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss");
        Date date = new Date(currentTime);
        String time=formatter.format(date);
        return time;
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser)
    {
        if (isVisibleToUser)
        {
            initWithVoice();
            String tokeninfomation=query_token();
            if(tokeninfomation==null||tokeninfomation.equals("loginout"))
            {
                AlertDialog dialog=new AlertDialog.Builder(getContext()).setTitle("未连接至服务器！")
                        .setMessage("无法同步音频数据，请先登录。")
                        .setIcon(R.drawable.head)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent intenttologin=new Intent(getActivity(),LoginActivity.class);
                                startActivity(intenttologin);
                            }
                        }).setNegativeButton("取消",null).show();
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(R.color.colorPrimaryDark);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(R.color.colorPrimaryDark);
            }
        }
        super.setUserVisibleHint(isVisibleToUser);
    }
    public void onDestroy() {
        super.onDestroy();
        db.close();
    }
}
