package com.example.mrtf.voicerecorder;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.jar.Manifest;

public class RecorderVoiceAdapter extends ArrayAdapter<RecorderVoice> {
    private int resourceId;
    private onClickImagbutton onClickImagbutton;

    public RecorderVoiceAdapter(Context context, int resource, List<RecorderVoice> objects) {
        super(context, resource, objects);
        resourceId=resource;
    }
    public View getView(final int position, View convertView, ViewGroup parent) {
        final RecorderVoice recorderVoice=getItem(position);
        final ViewHolder viewHolder;
        if (convertView==null)
        {
            viewHolder=new ViewHolder();
            convertView= LayoutInflater.from(getContext()).inflate(resourceId,parent,false);
            viewHolder.headerImage= (ImageView)convertView.findViewById(R.id.header_Image);
            viewHolder.palyImage= (ImageButton) convertView.findViewById(R.id.play__Image);
            viewHolder.voicename= (TextView) convertView.findViewById(R.id.voice_name);
            viewHolder.voicetime= (TextView) convertView.findViewById(R.id.voice_time);
            viewHolder.voicerecodertime=(TextView)convertView.findViewById(R.id.voice_recodertime) ;
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder= (ViewHolder) convertView.getTag();
        }
        viewHolder.headerImage.setImageResource(recorderVoice.getHeader_imageId());
        viewHolder.palyImage.setImageResource(recorderVoice.getPaly_imageId());
        viewHolder.voicename.setText(recorderVoice.getName().substring(36));
        viewHolder.voicetime.setText(recorderVoice.getVoicetime());
        viewHolder.voicerecodertime.setText(recorderVoice.getRecodertime());
        viewHolder.palyImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickImagbutton.ImagbuttonClick(recorderVoice);
            }
        });
        return convertView;
    }
    public final class ViewHolder
    {
        public ImageView headerImage;
        public ImageButton palyImage;
        public TextView voicename;
        public TextView voicetime;
        public TextView voicerecodertime;
    }
    public interface onClickImagbutton{
        void ImagbuttonClick(RecorderVoice recorderVoice);
    }
    public void setOnClickImagbutton(onClickImagbutton onClickImagbutton) {
        this.onClickImagbutton = onClickImagbutton;
    }

}
