package com.example.mrtf.voicerecorder;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.ListFragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.kaopiz.kprogresshud.KProgressHUD;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;



/**
 * A simple {@link Fragment} subclass.
 */
public class LocalStorageFragment extends ListFragment {

    private View view;
    private ListView listView;
    private RecorderVoiceAdapter adapter;
    private ArrayList<RecorderVoice> voiceslist=new ArrayList<>();
    private ArrayList<String>voicepath=new ArrayList<>();
    private RequestBody requestBody2;
    private File newFile;
    private static SimpleDBHelper dbHelper;
    public SQLiteDatabase db;
    private PlayVoiceDialogFragment playVoiceDialogFragment;
    public String voicename;
    private KProgressHUD hud;
    public String username;

    public LocalStorageFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_local_storage, container, false);
        listView=view.findViewById(android.R.id.list);
        dbHelper = new SimpleDBHelper(getContext(), 1);
        db=dbHelper.getWritableDatabase();
        initWithVoice();
        username=query_username();
        registerForContextMenu(listView);
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mMessageReceiver,
                new IntentFilter("MainActivitytofragment"));
        return view;
    }

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    hud=KProgressHUD.create(getActivity())
                            .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                            .setLabel("正在上传...")
                            .setCancellable(true)
                            .setAnimationSpeed(2)
                            .setDimAmount(0.5f)
                            .show();
                    break;
                case 2:
                    hud.dismiss();
                    Toast.makeText(getContext(),"音频文件上传成功",Toast.LENGTH_SHORT).show();
                    break;
                case 3:
                    hud.dismiss();
                    Toast.makeText(getContext(),"音频文件上传失败",Toast.LENGTH_SHORT).show();
                    break;
                case 4:
                    Toast.makeText(getActivity(),"文件上传失败，无法分享",Toast.LENGTH_LONG).show();
                    break;
                case 5:
                    Toast.makeText(getActivity(),"文件上传成功，开始分享",Toast.LENGTH_LONG).show();
                    break;

            }
        }
    };

    public void initWithVoice()
    {
        voicepath.clear();
        voiceslist.clear();
        query_all();
        adapter= new RecorderVoiceAdapter(this.getActivity(),R.layout.voice_item,voiceslist);
        listView.setAdapter(adapter);
        adapter.setOnClickImagbutton(new RecorderVoiceAdapter.onClickImagbutton() {
            public void ImagbuttonClick(final RecorderVoice recorderVoice) {
                voicename=recorderVoice.getName().substring(36);

                Intent intent = new Intent(getActivity(), MyService.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("Key", MyService.Control.PLAY);
                bundle.putString("voicepath",recorderVoice.getName());
                intent.putExtras(bundle);
                getActivity().startService(intent);


                FragmentManager fragmentManager=getFragmentManager();
                playVoiceDialogFragment=new PlayVoiceDialogFragment();
                Bundle bundle1 = new Bundle();
                bundle1.putInt("itemtime", recorderVoice.getGetduration());
                bundle1.putString("itemname",voicename);
                playVoiceDialogFragment.setArguments(bundle1);
                playVoiceDialogFragment.show(fragmentManager,"delete_dlg");

            }
        });
    }

    public String query_username()
    {

        Cursor cursor=db.query("LoginInformation",null,null,null,null,null,null);
        if(cursor.moveToFirst())
        {
            do {
                String name=cursor.getString(cursor.getColumnIndex("username"));
                return name;
            }while(cursor.moveToNext());
        }
        cursor.close();
        return null;
    }
    public String query_token()
    {
        Cursor cursor=db.query("LoginInformation",null,null,null,null,null,null);
        if(cursor.moveToFirst())
        {
            do {
                String token=cursor.getString(cursor.getColumnIndex("token"));
                return token;
            }while(cursor.moveToNext());
        }
        cursor.close();
        return null;
    }
    public void query_all()
    {
        Cursor cursor=db.query("VoiceRecorder",null,null,null,null,null,null);
        if(cursor.moveToFirst())
        {
            do {
                String voicepath=cursor.getString(cursor.getColumnIndex("voicepath"));
                String voicetime=cursor.getString(cursor.getColumnIndex("voicetime"));
                String recordertime=cursor.getString(cursor.getColumnIndex("recordertime"));
                int getduration=cursor.getInt(cursor.getColumnIndex("getduration"));
                int isupload=cursor.getInt(cursor.getColumnIndex("isupload"));
                Log.v("本地数据库中的全部信息",voicepath+" "+voicetime+" "+recordertime+ " "+String.valueOf(getduration)+" "+String.valueOf(isupload));
                RecorderVoice recorderVoice=new RecorderVoice(voicepath,getResources().getIdentifier("music", "drawable", this.getActivity().getPackageName()),getResources().getIdentifier("play_small", "drawable", this.getActivity().getPackageName()),voicetime,recordertime,getduration,isupload);
                voiceslist.add(recorderVoice);
            }while(cursor.moveToNext());
            cursor.close();
        }
    }


    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        menu.setHeaderTitle("录音文件操作");
        menu.add(0, 1, Menu.NONE, "上传");
        menu.add(0, 2, Menu.NONE, "分享");
        menu.add(0, 3, Menu.NONE, "重命名");
        menu.add(0, 4, Menu.NONE, "删除");
    }

    @SuppressLint("ResourceAsColor")
    public boolean onContextItemSelected(MenuItem item) {
        final AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        final RecorderVoice recorder=voiceslist.get(menuInfo.position);
        String tokeninfomation=query_token();
        switch(item.getItemId()) {
            case 1:
            {
                if(tokeninfomation==null||tokeninfomation.equals("loginout"))
                {
                    Toast.makeText(getActivity(),"未登录，不能进行上传",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Thread thread = new Thread(new Runnable(){
                        @Override
                        public void run(){
                            Message msg =Message.obtain();
                            msg.what=1;
                            handler.sendMessage(msg);
                            uploadFile(recorder);
                        }
                    });
                    thread.start();
                }
            }
            break;
            case 2:
            {
                if(tokeninfomation==null||tokeninfomation.equals("loginout"))
                {
                    Toast.makeText(getActivity(),"未登录，不能进行分享",Toast.LENGTH_LONG).show();
                }
                else {
                    if(recorder.getIsupload()==0)
                    {
                        Thread thread = new Thread(new Runnable(){
                            @Override
                            public void run(){
                                uploadFile_toshare(recorder);
                            }
                        });
                        thread.start();
                    }
                    new ConfirmPopWindow(getActivity(),recorder,username).showAtBottom(view);
                }
            }
            break;
            case 3:
            {
                final EditText et = new EditText(getContext());
                AlertDialog dialog=new AlertDialog.Builder(getContext()).setTitle("请输入重命名")
                        .setIcon(android.R.drawable.sym_def_app_icon)
                        .setView(et)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Thread thread = new Thread(new Runnable(){
                                    @Override
                                    public void run(){
                                        chageFileName(recorder.getName(), String.valueOf(et.getText()));
                                    }
                                });
                                thread.start();
                                initWithVoice();
                            }
                        }).setNegativeButton("取消",null).show();
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(R.color.colorPrimaryDark);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(R.color.colorPrimaryDark);

            }
            break;
            case 4:
            {
                AlertDialog dialog=new AlertDialog.Builder(getContext()).setTitle("确认删除"+recorder.getName().substring(36)+"？")
                        .setIcon(android.R.drawable.sym_def_app_icon)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Thread thread = new Thread(new Runnable(){
                                    @Override
                                    public void run(){
                                        deleteFile(recorder.getName());
                                    }
                                });
                                thread.start();
                                db.delete("VoiceRecorder","voicepath=?",new String[]{recorder.getName()});
                                String sql="update CloudRecorder set exits=0 where fileName=?";
                                db.execSQL(sql,new String[]{recorder.getName().substring(36)});
                                voiceslist.remove(menuInfo.position);
                                listView.setAdapter(adapter);
                            }
                        }).setNegativeButton("取消",null).show();
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(R.color.colorPrimaryDark);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(R.color.colorPrimaryDark);

            }
            break;
            default:
                return super.onContextItemSelected(item);
        }
        return true;
    }
    public void chageFileName(String filePath,String reName){
        File file = new File(filePath);
        String path = filePath.substring(0, filePath.lastIndexOf("/")+1)+reName+filePath.substring(filePath.lastIndexOf("."), filePath.length());
        newFile = new File(path);
        file.renameTo(newFile);
    }
    public void deleteFile(String filepath)
    {
        File file=new File(filepath);
        if(file.isFile()&&file.exists())
        {
            file.delete();
        }
    }
    public void uploadFile(final RecorderVoice recorder)
    {
        String url_upload="http://www.dgutguanyin.online/upload";
        OkHttpClient okHttpClient = new OkHttpClient();
        File file = new File(recorder.getName());
        if (!file.exists()){
            Toast.makeText(getActivity(), "文件不存在", Toast.LENGTH_SHORT).show();
        }
        else{
            String username=query_username();
            requestBody2 = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("file",file.getName(),RequestBody.create(MediaType.parse("application/octet-stream"), file))
                    .addFormDataPart("name",username)
                    .addFormDataPart("time",String.valueOf(recorder.getGetduration()))
                    .build();
            Request request = new Request.Builder().url(url_upload).post(requestBody2).build();
            Call call = okHttpClient.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.v("上传失败",e.getLocalizedMessage());
                    Message msg =Message.obtain();
                    msg.what=3;
                    handler.sendMessage(msg);

                }
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String sql="update VoiceRecorder set isupload=1 where voicepath=?";
                    db.execSQL(sql,new String[]{recorder.getName()});
                    Message msg =Message.obtain();
                    msg.what=2;
                    handler.sendMessage(msg);
                }
            });
        }
    }

    public void uploadFile_toshare(final RecorderVoice recorder)
    {
        String url_upload="http://www.dgutguanyin.online/upload";
        OkHttpClient okHttpClient = new OkHttpClient();
        File file = new File(recorder.getName());
        if (!file.exists()){
            Toast.makeText(getActivity(), "文件不存在", Toast.LENGTH_SHORT).show();
        }
        else{
            requestBody2 = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("file",file.getName(),RequestBody.create(MediaType.parse("application/octet-stream"), file))
                    .addFormDataPart("name",username)
                    .addFormDataPart("time",String.valueOf(recorder.getGetduration()))
                    .build();
            Request request = new Request.Builder().url(url_upload).post(requestBody2).build();
            Call call = okHttpClient.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Message msg =Message.obtain();
                    msg.what=4;
                    handler.sendMessage(msg);

                }
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    Message msg =Message.obtain();
                    msg.what=5;
                    handler.sendMessage(msg);
                    String sql="update VoiceRecorder set isupload=1 where voicepath=?";
                    db.execSQL(sql,new String[]{recorder.getName()});
                }
            });
        }
    }

    public void onDestroy() {
        super.onDestroy();
        db.close();
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mMessageReceiver);
    }
    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent!=null)
            {
               initWithVoice();
            }

        }
    };

}


