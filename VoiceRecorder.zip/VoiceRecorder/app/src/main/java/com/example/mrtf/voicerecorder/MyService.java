package com.example.mrtf.voicerecorder;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;

public class MyService extends Service {
    private MediaPlayer mediaPlayer;
    private int startId;
    public MyService() {
        super();
    }

    public enum Control {
        PLAY, PAUSE, STOP
    }
    
    @Override
    public void onCreate() {
        if (mediaPlayer == null) {
            mediaPlayer =new MediaPlayer();
        }
        super.onCreate();
    }
    public int onStartCommand(Intent intent, int flags, int startId) {
        this.startId = startId;
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            Control control = (Control) bundle.getSerializable("Key");
            final String voice_path=bundle.getString("voicepath");
            if (control != null) {
                switch (control) {
                    case PLAY: {
                        Thread thread = new Thread(new Runnable(){
                            @Override
                            public void run(){
                                playMusic(voice_path);
                            }
                        });
                        thread.start();
                        break;
                    }
                    case STOP:
                        stop();
                    default:
                        break;
                }
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }
    private void playMusic(final String path) {
        try {
            //设置资源
            mediaPlayer.reset();
            mediaPlayer.setDataSource(path);
            mediaPlayer.prepareAsync();
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mediaPlayer.start();
                }
            });
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    stop();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
        super.onDestroy();
    }

    private void stop() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
        }
        else {
            mediaPlayer=new MediaPlayer();
            mediaPlayer.release();
        }
        stopSelf(startId);
    }

    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

}

