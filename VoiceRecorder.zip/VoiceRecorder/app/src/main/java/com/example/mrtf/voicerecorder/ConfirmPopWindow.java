package com.example.mrtf.voicerecorder;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class ConfirmPopWindow extends PopupWindow implements View.OnClickListener {
    private Context context;
    private View ll_chat, ll_friend ,ll_favorite;
    private RecorderVoice  recorderVoice;
    public String username;
    private String url;

    public ConfirmPopWindow(Context context,RecorderVoice recorderVoice,String username) {
        super(context);
        this.context = context;
        this.recorderVoice=recorderVoice;
        this.username=username;
        initalize();
    }

    private void initalize() {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.confirm_dialog, null);
        ll_chat = view.findViewById(R.id.ll_chat);
        ll_friend = view.findViewById(R.id.ll_friend);
        ll_favorite=view.findViewById(R.id.ll_favorite);
        ll_chat.setOnClickListener(this);
        ll_friend.setOnClickListener(this);
        ll_favorite.setOnClickListener(this);
        setContentView(view);
        initWindow();
    }

    private void initWindow() {
        DisplayMetrics d = context.getResources().getDisplayMetrics();
        this.setWidth((int) (d.widthPixels));
        this.setHeight(RadioGroup.LayoutParams.WRAP_CONTENT);
        this.setFocusable(true);
        this.setOutsideTouchable(true);
        this.update();
        ColorDrawable dw = new ColorDrawable(0x00000000);
        this.setBackgroundDrawable(dw);
        backgroundAlpha((Activity) context, 0.8f);
        this.setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss() {
                backgroundAlpha((Activity) context, 1f);
            }
        });
    }

    public void backgroundAlpha(Activity context, float bgAlpha) {
        WindowManager.LayoutParams lp = context.getWindow().getAttributes();
        lp.alpha = bgAlpha;
        context.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        context.getWindow().setAttributes(lp);
    }
    public void showAtBottom(View view) {
        showAsDropDown(view, Math.abs((view.getWidth() - getWidth()) / 2), Math.abs((view.getHeight() - getHeight())/3));
    }
    @Override
    public void onClick(View view) {
        String filename=recorderVoice.getName().substring(36);
        try {
            url = "http://www.dgutguanyin.online/shareRecorder?name="+URLEncoder.encode(username, "utf-8")+"&&fileName="+URLEncoder.encode(filename, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        switch (view.getId()) {
            case R.id.ll_chat:
                Toast.makeText(context, "微信好友", Toast.LENGTH_SHORT).show();
                WeChatShare.regToWx(context)
                        .setWhere(WxShareTo.share_session)
                        .setType(WxShareType.type_webPage)
                        .addUrl(url)
                        .share(recorderVoice,username);
                break;
            case R.id.ll_friend:
               WeChatShare.regToWx(context)
                        .setWhere(WxShareTo.share_timeline)
                        .setType(WxShareType.type_webPage)
                        .addUrl(url)
                       .share(recorderVoice,username);
                Toast.makeText(context, "朋友圈", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ll_favorite:
                 WeChatShare.regToWx(context)
                        .setWhere(WxShareTo.share_favorite)
                        .setType(WxShareType.type_webPage)
                        .addUrl(url)
                       .share(recorderVoice,username);
                Toast.makeText(context, "收藏", Toast.LENGTH_SHORT).show();
                break;
            default:
                break;
        }
    }
}

