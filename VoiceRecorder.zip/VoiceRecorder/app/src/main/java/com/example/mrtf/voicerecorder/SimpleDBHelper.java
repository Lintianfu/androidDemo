package com.example.mrtf.voicerecorder;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class SimpleDBHelper extends SQLiteOpenHelper {
    private static final String DBName = "VoiceRecorder.db";
    private static final String VoiceRecorder = "VoiceRecorder";
    private static final String CloudRecorder="CloudRecorder";
    private static final String LoginInformation="LoginInformation";

    private static final String CREATE_Recorder_TABLE
            = "create table " + VoiceRecorder + "(id integer primary key autoincrement,voicepath text,voicetime text,recordertime text,getduration int,isupload int)";
    private static final String CREATE_Cloud_TABLE
            = "create table " + CloudRecorder + "(id integer primary key autoincrement,fileName text,filePath text,createDate text,exits int,getduration int,user text)";
    private static final String CREATE_Login_TABLE
            = "create table " + LoginInformation + "(id integer primary key autoincrement,token text,username text)";
    private static final String InitWithLogin="insert into LoginInformation(token, username) values('loginout','用户名')";

    public SimpleDBHelper(Context context, int version) {
        super(context, DBName, null, version);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_Recorder_TABLE);
        db.execSQL(CREATE_Cloud_TABLE);
        db.execSQL(CREATE_Login_TABLE);
        db.execSQL(InitWithLogin);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        switch (i) {
            case 1:
                break;

            default:
                throw new IllegalStateException("unknown oldVersion " + i);
        }

    }
}
