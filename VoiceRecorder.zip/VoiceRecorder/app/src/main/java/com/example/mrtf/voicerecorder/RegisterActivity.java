package com.example.mrtf.voicerecorder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class RegisterActivity extends AppCompatActivity {

    public Button sure_register;
    public Button calcel_register;
    public EditText name_edit;
    public EditText email_edit;
    public EditText password_edit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ActivityManager.getInstance().addActivity(this);
        sure_register=(Button)findViewById(R.id.btnRegister);
        calcel_register=(Button)findViewById(R.id.btnCancel);
        name_edit=(EditText) findViewById(R.id.edit_Name);
        email_edit=(EditText)findViewById(R.id.edit_Email);
        password_edit=(EditText)findViewById(R.id.edit_Password);
        sure_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Thread thread = new Thread(new Runnable(){
                    @Override
                    public void run(){
                        postFormRegister();
                    }
                });
                thread.start();
                finish();
            }
        });
        calcel_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    public void postFormRegister() {
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("name", name_edit.getText().toString())
                .addFormDataPart("email", email_edit.getText().toString())
                .addFormDataPart("password", getDES(password_edit.getText().toString()))
                .build();
        final Request request = new Request.Builder()
                .url("http://www.dgutguanyin.online/register")
                .post(requestBody)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {

            }
        });
    }
    public String getDES(String DESpassword)
    {
        try {
            DesUtils des = new DesUtils("dgutguanyin");
            String DES_Password=des.encrypt(DESpassword);
            return DES_Password;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
