package com.example.mrtf.voicerecorder;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import java.util.List;

public class CloudVoiceAdapter  extends ArrayAdapter<CloudVoice> {
    private int resourceId;
    private CloudVoiceAdapter.onClickImagbutton onClickImagbutton;
    public CloudVoiceAdapter(Context context, int resource, List<CloudVoice> objects) {
        super(context, resource, objects);
        resourceId=resource;

    }
    public View getView(final int position, View convertView, ViewGroup parent) {
        final CloudVoice cloudVoice=getItem(position);
        final CloudVoiceAdapter.ViewHolder viewHolder;
        if (convertView==null)
        {
            viewHolder=new CloudVoiceAdapter.ViewHolder();
            convertView= LayoutInflater.from(getContext()).inflate(resourceId,parent,false);
            viewHolder.headerImage= (ImageView)convertView.findViewById(R.id.header_Image);
            viewHolder.palyImage= (ImageButton) convertView.findViewById(R.id.play__Image);
            viewHolder.voicename= (TextView) convertView.findViewById(R.id.voice_name);
            viewHolder.voicerecodertime=(TextView)convertView.findViewById(R.id.voice_recodertime) ;
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder= (CloudVoiceAdapter.ViewHolder) convertView.getTag();
        }
        viewHolder.headerImage.setImageResource(cloudVoice.getHeader_imageId());
        viewHolder.palyImage.setImageResource(cloudVoice.getPaly_imageId());
        viewHolder.voicename.setText(cloudVoice.getName());
        viewHolder.voicerecodertime.setText(cloudVoice.getRecodertime());
        viewHolder.palyImage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                onClickImagbutton.ImagbuttonClick(cloudVoice,position);
            }
        });
        return convertView;
    }
    public final class ViewHolder
    {
        public ImageView headerImage;
        public ImageButton palyImage;
        public TextView voicename;
        public TextView voicerecodertime;
    }
    public interface onClickImagbutton{
         void ImagbuttonClick(CloudVoice cloudVoice,int position);
    }
    public void setOnClickImagbutton(CloudVoiceAdapter.onClickImagbutton onClickImagbutton) {
        this.onClickImagbutton = onClickImagbutton;
    }
    public void update(int index,ListView listview){
        int visiblePosition = listview.getFirstVisiblePosition();
        View view = listview.getChildAt(index - visiblePosition);
        ViewHolder holder = (ViewHolder) view.getTag();
        holder.palyImage.setImageResource(R.drawable.play);
    }
}
