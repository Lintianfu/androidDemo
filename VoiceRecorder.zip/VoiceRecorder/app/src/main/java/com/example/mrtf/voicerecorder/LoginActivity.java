package com.example.mrtf.voicerecorder;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.kaopiz.kprogresshud.KProgressHUD;
import org.json.JSONObject;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LoginActivity extends AppCompatActivity {

    protected View view;
    protected Context context;
    public Button registbtn;
    public Button loginbtn;
    public Button forgotpasswoed;
    public EditText edit_email;
    public EditText edit_password;
    private static SimpleDBHelper dbHelper;
    public SQLiteDatabase db;
    private KProgressHUD hud;
    private OkHttpClient.Builder builder;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ActivityManager.getInstance().addActivity(this);
        dbHelper = new SimpleDBHelper(this, 1);
        db=dbHelper.getWritableDatabase();
        loginbtn=(Button) findViewById(R.id.btn_Login);
        registbtn=(Button)findViewById(R.id.btn_Register);
        forgotpasswoed=(Button) findViewById(R.id.btn_ForgotPassword);
        edit_email=(EditText)findViewById(R.id.edit_Email);
        edit_password=(EditText)findViewById(R.id.edit_Password);
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);

                Thread thread = new Thread(new Runnable(){
                    @Override
                    public void run(){
                        Message msg =Message.obtain();
                        msg.what=1;
                        handler.sendMessage(msg);
                        postFormLogin();
                    }
                });
                thread.start();
            }
        });
        registbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_regist=new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent_regist);
            }
        });

        forgotpasswoed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edit_email.getText().toString()==null)
                {
                    Toast.makeText(LoginActivity.this,"请输入用户邮箱",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    new AlertDialog.Builder(LoginActivity.this)
                            .setTitle("提醒")
                            .setIcon(R.mipmap.ic_launcher)
                            .setMessage("用户密码发送至"+edit_email.getText().toString()+"?")
                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    Thread thread = new Thread(new Runnable(){
                                        @Override
                                        public void run(){
                                           postFormForget(edit_email.getText().toString());
                                        }
                                    });
                                    thread.start();
                                    Toast.makeText(LoginActivity.this,"邮件已发送，请查收",Toast.LENGTH_SHORT).show();
                                }
                            })
                            .setNegativeButton("取消", null).show();
                }

            }

        });
    }
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    hud=KProgressHUD.create(LoginActivity.this)
                            .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                            .setLabel("正在登录...")
                            .setCancellable(true)
                            .setAnimationSpeed(2)
                            .setDimAmount(0.5f)
                            .show();
                    break;
                case 2:
                    scheduleDismiss();
                    finish();
                    break;
                case 3:
                    hud.dismiss();
                    Toast.makeText(LoginActivity.this,"登录失败",Toast.LENGTH_SHORT).show();
                    break;
                case 4:
                    hud.dismiss();
                    new AlertDialog.Builder(LoginActivity.this)
                            .setTitle(msg.obj+","+"请重新输入！")
                            .setPositiveButton("确定", null)
                            .show();
            }
        }
    };

    public void postFormLogin() {
       /* builder = new OkHttpClient.Builder();
        builder.followRedirects(true);
        OkHttpClient client = builder.build();*/
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("email", edit_email.getText().toString())
                .addFormDataPart("password", getDES(edit_password.getText().toString()))
                .build();
        final Request request = new Request.Builder()
                .url("http://www.dgutguanyin.online/login")
                .post(requestBody)
                .header("Connection","close")
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Message msg =Message.obtain();
                msg.what=3;
                handler.sendMessage(msg);
                Log.v("请求失败的原因",e.getLocalizedMessage());
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseStr = response.body().string();
                parseJSONWithJSONObject(responseStr);
            }
        });
    }
    public void parseJSONWithJSONObject(String JsonData) {
        try
        {
            JSONObject jsonObject=new JSONObject(JsonData);
            int errorCode=jsonObject.getInt("errorCode");
            final String message=jsonObject.getString("message");
            switch (errorCode)
            {
                case 0:
                {
                    String datajson=jsonObject.getString("data");
                    JSONObject jsonObjectforname=new JSONObject(datajson);
                    String tokennow=jsonObject.getString("token");
                    String usernamenow=jsonObjectforname.getString("name");
                    ContentValues values = new ContentValues();
                    values.put("token", tokennow);
                    values.put("username",usernamenow);
                    db.update("LoginInformation", values, "id=?", new String[]{"1"});
                    db.close();
                    Intent intent2 = new Intent("custom-event-name");
                    intent2.putExtra("username",usernamenow);
                    LocalBroadcastManager.getInstance(this).sendBroadcast(intent2);
                    Message msg =Message.obtain();
                    msg.what=2;
                    handler.sendMessage(msg);
                    break;
                }
                case 1:
                {

                    Message msg =Message.obtain();
                    msg.obj=message;
                    msg.what=4;
                    handler.sendMessage(msg);
                    break;
                }
                default:
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    private void scheduleDismiss() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hud.dismiss();
            }
        }, 3000);
    }
    public void postFormForget(String email_user) {
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("email", email_user)

                .build();
        final Request request = new Request.Builder()
                .url("http://www.dgutguanyin.online/forgetPwd")
                .post(requestBody)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Toast.makeText(LoginActivity.this,e.getLocalizedMessage(),Toast.LENGTH_SHORT).show();

            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseStr = response.body().string();
            }
        });
    }
    public String getDES(String DESpassword)
    {
        try {
            DesUtils des = new DesUtils("dgutguanyin"); //自定义密钥
            String DES_Password=des.encrypt(DESpassword);
            return DES_Password;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
