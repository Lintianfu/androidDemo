package com.example.mrtf.voicerecorder;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

public class WelcomeActivity extends FragmentActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        ActivityManager.getInstance().addActivity(this);
        handler.sendEmptyMessageDelayed(0,1000);

    }
    public void Welcome()
    {

        Intent intent=new Intent(WelcomeActivity.this,TabFragmentActivity.class);
        startActivity(intent);
    }
    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            Welcome();
            super.handleMessage(msg);
        }
    };
}
