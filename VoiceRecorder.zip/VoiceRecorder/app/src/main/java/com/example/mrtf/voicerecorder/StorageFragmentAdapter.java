package com.example.mrtf.voicerecorder;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;


import java.util.List;

public class StorageFragmentAdapter extends FragmentPagerAdapter {

    public FragmentManager fragmetnmanager;
    private List<Fragment> listfragment;

    public StorageFragmentAdapter(FragmentManager fm,List<Fragment> list) {
        super(fm);
        this.fragmetnmanager=fm;
        this.listfragment=list;
    }
    @Override
    public Fragment getItem(int arg0) {
        return listfragment.get(arg0);
    }
    @Override
    public int getCount() {
        return listfragment.size();
    }


}