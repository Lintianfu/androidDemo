package com.example.mrtf.voicerecorder;


import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;



/**
 * A simple {@link Fragment} subclass.
 */
public class MyisloginFragment extends Fragment {
    View view;
    private TextView back_btn;
    private TextView user_name;
    private TextView voice_number;
    private TextView modify_password;

    private LinearLayout back_layout;
    private LinearLayout modify_password_layout;
    private LinearLayout top_layout;

    private static SimpleDBHelper dbHelper;
    public SQLiteDatabase db;
    private String username;

    public MyisloginFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        if(view==null){
            view=inflater.inflate(R.layout.fragment_myislogin, null);
        }
        ViewGroup parent = (ViewGroup) view.getParent();
        if (parent != null) {
            parent.removeView(view);
        }
        dbHelper = new SimpleDBHelper(getActivity(), 1);
        db=dbHelper.getWritableDatabase();
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mMessageReceiver,
                new IntentFilter("custom-event-name"));

        back_btn=(TextView)view.findViewById(R.id.turnoff_text);
        user_name=(TextView)view.findViewById(R.id.name);
        voice_number=(TextView)view.findViewById(R.id.music_number_text);
        modify_password=(TextView)view.findViewById(R.id.modify_view) ;

        modify_password_layout=(LinearLayout) view.findViewById(R.id.chuange_use);
        back_layout=(LinearLayout) view.findViewById(R.id.turnoff);
        top_layout=(LinearLayout)view.findViewById(R.id.topPanel) ;
        top_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tokeninfomation=query_token();
                if(tokeninfomation==null||tokeninfomation.equals("loginout"))
                {
                    Intent intenttologin=new Intent(getActivity(),LoginActivity.class);
                    startActivity(intenttologin);
                }

            }
        });
        voice_number.setText("音频数量  "+allCaseNum());
        username=query_username();
        if(!username.equals("用户名"))
        {
              user_name.setText(username);
        }

        modify_password_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tokeninfomation=query_token();
                if(tokeninfomation!=null&&!tokeninfomation.equals("loginout"))
                {
                    Intent intent_modify=new Intent(getActivity(),ModifyPWActivity.class);
                    startActivity(intent_modify);
                }

            }
        });
        back_layout.setOnClickListener(new View.OnClickListener() {
           @SuppressLint("ResourceAsColor")
           @Override
           public void onClick(View v) {
               AlertDialog dialog=new AlertDialog.Builder(getActivity()).setTitle("是否确定退出")
                       .setIcon(R.drawable.head)

                       .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int i) {
                               ContentValues values = new ContentValues();
                               values.put("token", "loginout");
                               values.put("username", "用户名");
                               db.update("LoginInformation", values, "id=?", new String[]{"1"});
                               TabFragmentActivity activity = (TabFragmentActivity) getActivity();
                               activity.getLoginStatus("YES");
                           }
                       })
                       .setNegativeButton("取消", null).show();
               dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(R.color.colorPrimaryDark);
               dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(R.color.colorPrimaryDark);

           }

       });
       return view;
    }
    public String query_username()
    {

        Cursor cursor=db.query("LoginInformation",null,null,null,null,null,null);
        if(cursor.moveToFirst())
        {
            do {
                String name=cursor.getString(cursor.getColumnIndex("username"));
                return name;
            }while(cursor.moveToNext());
        }
        cursor.close();
        return null;
    }
    public String query_token()
    {
        Cursor cursor=db.query("LoginInformation",null,null,null,null,null,null);
        if(cursor.moveToFirst())
        {
            do {
                String token=cursor.getString(cursor.getColumnIndex("token"));
                return token;
            }while(cursor.moveToNext());
        }
        cursor.close();
        return null;
    }
    public String allCaseNum( ){
        String sql = "select count(*) from VoiceRecorder";
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        long count = cursor.getLong(0);
        cursor.close();
        return String.valueOf(count);
    }
    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            user_name.setText(intent.getStringExtra("username"));
        }

    };
    public void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mMessageReceiver);
        db.close();
    }
}
